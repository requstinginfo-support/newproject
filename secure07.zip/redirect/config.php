<?php

//Telegram_Config//
const BOT_TOKEN = '1708216491:AAEjykm3wITWERQPlg1C7yK0sNVibXB7rLw';
const BOT_ADMIN_USERID = 1310201514;
const TELEGRAM_BOT_REPORT_EVERY_TIME = false;
//Telegram_Config//

?>